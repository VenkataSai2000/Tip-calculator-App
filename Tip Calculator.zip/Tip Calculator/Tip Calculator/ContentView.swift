//
//  ContentView.swift
//  Tip Calculator
//
//  Created by Pulipati Venkata Sai on 13/04/23.
//

import SwiftUI

struct ContentView: View {
    @State var total = "0"
    @State var val = 15.0
    var body: some View {
        VStack{
            Text("* YUM YUM TREE *").italic().bold().font(.largeTitle)
            HStack{
                Image("RS")
                Text("Tip Calculator")
                .bold()
                .font(.largeTitle)
            }
            HStack{
                Text("Rs.").bold()
                TextField("Amount",text: $total)
            }
            HStack{
                Slider(value: $val,in: 1...50, step: 1.0)
                Text("\(Int(val))").bold()
                Text("%").bold()
            }
            VStack{
                Text("Tip Amount:").bold()
                if let totalAmnt = Double(total){
                    Text("Rs.\(Double(totalAmnt) * val / 100, specifier: "%0.2f")").bold()
                }else{
                    Text("Please enter only numericals!!").bold()
                }
            }
        }
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
