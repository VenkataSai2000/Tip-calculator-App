//
//  Tip_CalculatorApp.swift
//  Tip Calculator
//
//  Created by Pulipati Venkata Sai on 13/04/23.
//

import SwiftUI

@main
struct Tip_CalculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
